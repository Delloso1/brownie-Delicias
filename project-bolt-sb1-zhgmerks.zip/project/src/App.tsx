import React from 'react';
import { Phone, ShoppingBag, Truck, Award, Star, Package, MessageCircle } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-[#1a0f0f]">
      {/* Hero Section */}
      <div 
        className="min-h-[60vh] bg-cover bg-center relative"
        style={{
          backgroundImage: 'url("https://images.unsplash.com/photo-1606313564200-e75d5e30476c?ixlib=rb-1.2.1&auto=format&fit=crop&w=2000&q=80")',
        }}
      >
        <div className="absolute inset-0 bg-black/50" />
        <div className="relative container mx-auto px-4 py-20 text-center text-white">
          <h1 className="text-5xl md:text-6xl font-bold mb-4">Brownie Delícia</h1>
          <p className="text-2xl md:text-3xl mb-8">O Melhor Brownie da Região!</p>
          <div className="flex items-center justify-center space-x-2 text-xl">
            <Star className="text-yellow-400" />
            <p>O Sabor Perfeito em Cada Mordida!</p>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-16">
        {/* Description */}
        <div className="text-center text-white mb-16">
          <p className="text-xl mb-8">
            Quer um brownie irresistível, fofinho por dentro e crocante por fora? 
            Fazemos grandes quantidades para aniversários e festas!
          </p>
        </div>

        {/* Diferenciais */}
        <div className="grid md:grid-cols-4 gap-8 mb-16">
          {[
            { icon: Award, text: 'Brownie caseiro e artesanal' },
            { icon: Star, text: 'Feito com ingredientes de alta qualidade' },
            { icon: Package, text: 'Perfeito para qualquer ocasião' },
            { icon: Truck, text: 'Entrega rápida' },
          ].map((item, index) => (
            <div key={index} className="bg-[#2a1f1f] p-6 rounded-lg text-white text-center">
              <item.icon className="w-12 h-12 mx-auto mb-4 text-yellow-400" />
              <p className="text-lg">{item.text}</p>
            </div>
          ))}
        </div>

        {/* Preços */}
        <div className="bg-[#2a1f1f] rounded-lg p-8 mb-16">
          <h2 className="text-3xl font-bold text-white text-center mb-8">Preços e Entrega</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-[#3a2f2f] p-6 rounded-lg text-white">
              <ShoppingBag className="w-8 h-8 mb-4 text-yellow-400" />
              <h3 className="text-xl font-bold mb-2">Unidade</h3>
              <p className="text-2xl font-bold text-yellow-400">R$ 5,00</p>
            </div>
            <div className="bg-[#3a2f2f] p-6 rounded-lg text-white">
              <Package className="w-8 h-8 mb-4 text-yellow-400" />
              <h3 className="text-xl font-bold mb-2">Combo 2 unidades</h3>
              <p className="text-2xl font-bold text-yellow-400">R$ 8,00</p>
            </div>
          </div>
          <p className="text-white text-center mt-8">
            Pedidos para festas: consulte valores especiais e entre em contato!
          </p>
        </div>

        {/* Contact */}
        <div className="text-center text-white">
          <h2 className="text-3xl font-bold mb-8">Entre em Contato</h2>
          <div className="flex flex-col items-center space-y-4">
            <div className="flex items-center space-x-2">
              <Truck className="text-yellow-400" />
              <p className="text-xl">Entregamos na sua casa!</p>
            </div>
            <div className="flex items-center space-x-2">
              <MessageCircle className="text-yellow-400" />
              <p className="text-xl">Peça já o seu!</p>
            </div>
            <a 
              href="tel:+5592994256407" 
              className="flex items-center space-x-2 text-yellow-400 hover:text-yellow-300 transition-colors"
            >
              <Phone />
              <p className="text-xl">(92) 99425-6407</p>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;